
Gizmo TV Chatbot - Facebook Messenger + ChatGPT

1. Replace PASTE_YOUR_FACEBOOK_PAGE_TOKEN_HERE in app.py with your Facebook Page token.
2. Replace PASTE_YOUR_OPENAI_API_KEY_HERE with your ChatGPT API key.
3. Host this code on Render.com or Replit.com
4. On Meta Developer, add the webhook:
   - URL: [your host URL]
   - Verify Token: gizmosecret123
   - Subscribe to: messages, messaging_postbacks

Run the bot. Send a message to your page. It’ll respond via ChatGPT.
